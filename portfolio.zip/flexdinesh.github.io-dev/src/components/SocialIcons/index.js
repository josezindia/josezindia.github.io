import SocialIcons from './SocialIcons';

export default SocialIcons;