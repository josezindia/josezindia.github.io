# Dinesh Pandiyan

This repo holds my **Dev Landing Page**, a one stop shop to everything I do online. 🎉

`master` branch has the deploy files. The source code is in `dev` branch [here](https://github.com/flexdinesh/flexdinesh.github.io/tree/dev).

## License

MIT © Dinesh Pandiyan